#include <iostream>
#include <cstdlib>
using namespace std;

class Stack
{
	// "stackArray" is the array used to hold the values put into the stack.
	int *stackArray;

	// "top" is used to denote the size of the array.
	int top;

	// "max_Size" is used to denote the number of items that can be within the stack at one time.
	int max_Size;

public:
	Stack(int n);
	void push(int n);
	void pop();
	int size();
	bool empty();
	bool full();
};

Stack::Stack(int n)
{
	// The variable "n" passed into the constructor becomes the value of "max_Size" and an array is created using the new value.
	max_Size = n;
	stackArray = new int[max_Size];

	// Top is set to -1 to denote the stack as "empty."
	top = -1;
}

void Stack::push(int n)
{
	// The "push" function looks to see if the stack is full. If it isn't, the parameter "n" is pushed onto the top of the stack.
	if (!full())
	{
		stackArray[top++] = n; // Top is incremented as the new value is pushed to the stack.
	}
}

void Stack::pop()
{
	// The "pop" function looks to see if the stack is empty. If it isn't, the top value of the stack is removed.
	if (!empty())
	{
		stackArray[top--]; // Top is decremented as the top value is removed from the stack.
	}
}

int Stack::size()
{
	// Since top begins at a value of -1, the size of the stack at any point is the value of top increased by 1.
	return top + 1;
}

bool Stack::empty()
{
	// Since top begins as -1 in an empty stack, "empty()" checks to see if top is still -1. If it is, the function returns true.
	if (top == -1)
		return true;
	else
		return false;
}

bool Stack::full()
{
	// Since top is always one less than the actual size of the stack, "full()" checks to see if top equals 1 less than the stack's maximum size. If it is, the function returns true.
	if (top == max_Size - 1)
		return true;
	else
		return false;
}

int main()
{
	Stack s(10);
	int value;
	int option;
	cout << "Initial Stack Size: 10" << endl;
	do
	{
		cout << "~~~~~~~~~~~~~~~~~~~~" << endl;
		cout << "1. Push to Stack" << endl;
		cout << "2. Pop the Top" << endl;
		cout << "3. Stack Size" << endl;
		cout << "4. Is Stack Empty?" << endl;
		cout << "5. Is Stack Full?" << endl;
		cout << "6. Exit" << endl;
		cout << "Select an option: ";
		cin >> option;

		switch (option)
		{
		case 1:
			if (s.full())
				cout << "Unable to push, stack full." << endl;
			else
			{
				cout << "Enter a value: ";
				cin >> value;
				s.push(value);
			}
			break;
		case 2:
			if (s.empty())
				cout << "Unable to pop, stack empty." << endl;
			else
				s.pop();
			break;
		case 3:
			cout << "Stack Size: " << s.size() << endl;
			break;
		case 4:
			if(s.empty())
				cout << "Stack is empty." << endl;
			else
				cout << "Stack is not empty, " << s.size() << " spot(s) filled." << endl;
			break;
		case 5:
			if(s.full())
				cout << "Stack is full." << endl;
			else
				cout << "Stack is not full, " << 10 - s.size() << " spot(s) unfilled." << endl;
			break;
		}
	} while (option != 6);
	return 0;
}